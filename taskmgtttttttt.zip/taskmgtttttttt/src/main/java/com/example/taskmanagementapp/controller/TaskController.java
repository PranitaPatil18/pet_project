package com.example.taskmanagementapp.controller;

import com.example.taskmanagementapp.model.Task;
import com.example.taskmanagementapp.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/tasks")
public class TaskController {
    @Autowired
    private TaskService taskService;

    // Get all tasks
    @GetMapping
    public String getAllTasks(Model model) {
        model.addAttribute("tasks", taskService.getAllTasks());
        return "task-list";
    }
    
    

 // Filter tasks by status
    @GetMapping("/status/{status}")
    public String getTasksByStatus(@PathVariable String status, Model model) {
        model.addAttribute("tasks", taskService.getTasksByStatus(status));
        return "task-list";
    }

    // Show task creation form
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("task", new Task());
        return "task-form";
    }

    // Create a new task
    @PostMapping
    public String createTask(@ModelAttribute Task task) {
        taskService.createTask(task);
        return "redirect:/tasks";
    }

    // Show task update form
    @GetMapping("/{id}/edit")
    public String showUpdateForm(@PathVariable Long id, Model model) {
        model.addAttribute("task", taskService.getAllTasks().stream().filter(t -> t.getId().equals(id)).findFirst().orElse(null));
        return "task-form";
    }

    // Update a task
    @PostMapping("/{id}")
    public String updateTask(@PathVariable Long id, @ModelAttribute Task task) {
        taskService.updateTask(id, task);
        return "redirect:/tasks";
    }

    @PostMapping("/{id}/delete")
    public String deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
        return "redirect:/tasks";
    }

}
