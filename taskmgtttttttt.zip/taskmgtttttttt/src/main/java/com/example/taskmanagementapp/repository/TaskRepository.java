package com.example.taskmanagementapp.repository;

import com.example.taskmanagementapp.model.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
    
    // Custom method to find tasks by their status
    List<Task> findByStatus1(String status);
    
    // Custom method to find tasks by due date
    List<Task> findByDueDate(LocalDate dueDate);
    
    // Custom method to find tasks containing a specific keyword in the title
    List<Task> findByTitleContaining(String keyword);
    
    // Custom method to delete tasks by status
    void deleteByStatus(String status);
    
    // Custom method to update the status of a task
    @Modifying
    @Query("UPDATE Task t SET t.status = :newStatus WHERE t.id = :taskId")
    void updateStatus(@Param("taskId") Long taskId, @Param("newStatus") String newStatus);
    
    // Custom method to count tasks by status
    long countByStatus(String status);
    
    // Custom method to find tasks with a due date before a specific date
    List<Task> findByDueDateBefore(LocalDate date);
    
    // Custom method to find all completed tasks
    List<Task> findByStatus(String status);
}
