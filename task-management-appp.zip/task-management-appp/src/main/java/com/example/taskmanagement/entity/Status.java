package com.example.taskmanagement.entity;


public enum Status {
    PENDING,
    COMPLETED,
    IN_PROGRESS
}
